import{gettodaystemplate,getforecasttable} from '../utils/parser.js';
const renderforecast=(forecasttemplate,firstindex,lastindex)=>{
	const tablemarkup=forecasttemplate(firstindex,lastindex);
	const containernode=document.querySelector('.js-forecast');
	if(containernode) containernode.innerHTML=tablemarkup;
};

export const rendercity=({today,forecast,timezoneresponse})=>{
	const domelement=document.querySelector('.js-city-weather');
	const todaydata=gettodaystemplate(today,timezoneresponse);
let firstpage=0;
const numofrows=5;
	domelement.innerHTML=`${todaydata}
	<br>
	<button class="up-botton js-up" style="width:399px;">Up</button>
	
	<div class="js-forecast"> </div>
	
	<button class="down-botton js-down" style="width:399px;">Down</button>`;

	const forecasttemplate=getforecasttable(forecast,timezoneresponse);
	const wrapperrender=()=>
	renderforecast(forecasttemplate,firstpage,firstpage+numofrows-1);
	wrapperrender();

	const moveup=()=>{firstpage=Math.max(0,firstpage-1);
		wrapperrender();};
	const movedown=()=>{firstpage=Math.min(10,firstpage+1);
		wrapperrender();

	};

	document.querySelector('.js-up')
	.addEventListener('click',moveup);
	document.querySelector('.js-down')
	.addEventListener('click',movedown);


}