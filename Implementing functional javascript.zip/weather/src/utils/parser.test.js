import {expect} from 'chai';
import{getcity,getcountry,getweatherdata,gettodaystemperature,getsunrisesunset,gettodaystemplate,getforecastrow,getforecasttable} from './parser';

describe('parser util',()=>{
	it('shud return the city',()=>{
		expect(getcity({name:'City'})).to.equal('City');
	});
	it('shud return the country',()=>{
		expect(getcountry({
			sys:{
				country:'COUNTRY_CODE'
			}
		})).to.equal('COUNTRY_CODE')

	});
	it('shud return the weather condition and description',()=>{
		const input={
			weather:[
			{
				main:'Clouds',
				description:'scattered clouds'
			}]
		};
		const response='Clouds(scattered clouds)';
		expect(getweatherdata(input)).to.equal(response);
	});
	it('shud return todays temperature',()=>{
		const input={
			main:{
				temp: 20,
				temp_min: 18,
				temp_max: 22
			}
			
		};
		const response='Temperature(min,average,max): 18, 20, 22';
		expect(gettodaystemperature(input)).to.equal(response);
	});
	it('shud return the sunrise and sunset time',()=>{
		const weatherinput={
			sys:{
				sunrise:1494966143,
				sunset:1495004757
			}
		};
		const timezoneinput={
			timeZoneId:'Australia/Brisbane'
		};
		const response='Sunrise: 1:52:23 AM, Sunset: 12:35:57 PM';
				expect(getsunrisesunset(weatherinput,timezoneinput)).to.equal(response);


	});
	it('shud return the full template for today',()=>{
		const weatherinput={
			main:{
				temp: 20,
				temp_min: 18,
				temp_max: 22
			},
			weather:[
			{
				main:'Clouds',
				description:'scattered clouds'
			}],
			sys:{
				country:'COUNTRY_CODE',
				sunrise:1494966143,
				sunset:1495004757
			},
			name:'City'
		};
		const timezoneinput={
			timeZoneId:'Australia/Brisbane'
		}
		const response=`<div>City,COUNTRY_CODE:Clouds(scattered clouds)</div><div>Temperature(min,average,max): 18, 20, 22</div><div>Sunrise: 1:52:23 AM, Sunset: 12:35:57 PM</div>`.trim();
		expect(gettodaystemplate(weatherinput,timezoneinput)).to.equal(response);
	});
	it('shud return a forecast row',()=>{
		const forecastresponse={
			list:[{
				dt:1586595600,
				main:{ feels_like:20},
				weather:[{
					main:'Sunny',
					description:'sky is clear'
				}]
			},
			{
				dt:1586606400,
				main:{ feels_like:16},
				weather:[{
					main:'Clouds',
					description:'broken clouds'
				}]
			}	]
		};
		const timezoneresponse={
			timeZoneId:'Australia/Brisbane'
		};
		const firstrow=getforecastrow(forecastresponse,timezoneresponse)(0);
		const secondrow=getforecastrow(forecastresponse,timezoneresponse)(1);
		const expectedfirstrow=`
		<tr><td style="border: 1px solid black; padding: 8px;">Apr 11th</td><td style="border: 1px solid black; padding: 8px;">20</td><td style="border: 1px solid black; padding:8px;">Sunny(sky is clear)</td></tr>`.trim();
		const expectedsecondrow=`
		<tr><td style="border: 1px solid black; padding: 8px;">Apr 11th</td><td style="border: 1px solid black; padding: 8px;">16</td><td style="border: 1px solid black; padding:8px;">Clouds(broken clouds)</td></tr>`.trim();
		expect(firstrow).to.equal(expectedfirstrow);
		expect(secondrow).to.equal(expectedsecondrow);
	});
	it('shud return the full forecast table',()=>{
		const forecastresponse={
			list:[{
				dt:1586595600,
				main:{ feels_like:20},
				weather:[{
					main:'Sunny',
					description:'sky is clear'
				}]
			},
			{
				dt:1586606400,
				main:{ feels_like:16},
				weather:[{
					main:'Clouds',
					description:'broken clouds'
				}]
			}	]
		};
		const timezoneresponse={
			timeZoneId:'Australia/Brisbane'
		};
		const table=getforecasttable(forecastresponse,timezoneresponse)(0,1);
		const expectedresult=`
		<table style="border: 1px solid black; border-collapse: collapse;"><tr><th style="border: 1px solid black; padding: 15px;">Date</th><th style="border: 1px solid black; padding: 15px;">Temperature (C)</th><th style="border: 1px solid black; padding: 15px;">Weather description</th></tr><tr><td style="border: 1px solid black; padding: 8px;">Apr 11th</td><td style="border: 1px solid black; padding: 8px;">20</td><td style="border: 1px solid black; padding:8px;">Sunny(sky is clear)</td></tr><tr><td style="border: 1px solid black; padding: 8px;">Apr 11th</td><td style="border: 1px solid black; padding: 8px;">16</td><td style="border: 1px solid black; padding:8px;">Clouds(broken clouds)</td></tr></table>`.trim();
		expect(table).to.equal(expectedresult);


	});
});