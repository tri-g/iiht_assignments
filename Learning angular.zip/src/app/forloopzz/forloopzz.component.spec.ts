import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ForloopzzComponent } from './forloopzz.component';

describe('ForloopzzComponent', () => {
  let component: ForloopzzComponent;
  let fixture: ComponentFixture<ForloopzzComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ForloopzzComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ForloopzzComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
