import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forloopzz',
  templateUrl: './forloopzz.component.html',
  styleUrls: ['./forloopzz.component.css']
})
export class ForloopzzComponent implements OnInit {

 name=['tri','pooja','tony','roger','steve'];
	n='';
	addnames()
	{
		this.name.push(this.n);
	}


  constructor() { }

  ngOnInit() {
  }

}