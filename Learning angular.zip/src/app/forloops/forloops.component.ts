import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forloops',
  templateUrl: './forloops.component.html',
  styleUrls: ['./forloops.component.css']
})
export class ForloopsComponent implements OnInit {

 title="fruits for loop";
fruits=['apple','kiwi','strawberry','avocado'];
fr=this.fruits[3];
  constructor() { }

  ngOnInit() {
  }

}