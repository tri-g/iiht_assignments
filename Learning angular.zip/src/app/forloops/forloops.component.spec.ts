import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ForloopsComponent } from './forloops.component';

describe('ForloopsComponent', () => {
  let component: ForloopsComponent;
  let fixture: ComponentFixture<ForloopsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ForloopsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ForloopsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
