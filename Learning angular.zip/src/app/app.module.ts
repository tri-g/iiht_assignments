import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { ForloopsComponent } from './forloops/forloops.component';
import { ForloopzzComponent } from './forloopzz/forloopzz.component';
import { IfcompComponent } from './ifcomp/ifcomp.component';

@NgModule({
  declarations: [
    AppComponent,
    ForloopsComponent,
    ForloopzzComponent,
    IfcompComponent
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
