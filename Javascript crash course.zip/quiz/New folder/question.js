questions=new Array();
questions.push("Captain America\'s\ shield is made of");
questions.push("What was Dr. Strange\'s\ profession before he became Sorcerer Supreme?");
questions.push("What is the name of Tony Stark\'s\ personal butler?");
questions.push("Who is Thor\'s\ adopted sibling?");
questions.push("F.R.I.D.A.Y. is an artificial intelligence unit created by:");

quesoneans=new Array("Vibranium","Adamantium","Kryptonite","Chrome");
questwoans=new Array("Professor","Dermatologist","Dentist","Neurosurgeon");
questhreeans=new Array("Jeeves","Jarvis","Alfred","Chrome");
quesfourans=new Array("Odin","Loki","Erik Selvig","Laufey");
quesfiveans=new Array("Edwin Jarvis","Nick Fury","War Machine","Tony Stark");

correct=new Array(0,3,1,1,3);

