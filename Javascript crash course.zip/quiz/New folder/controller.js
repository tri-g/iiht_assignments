var qno;
var score;
window.onload=function()
{
	qno=0;
	score=0;
	for(x=0;x<4;x++)
	{
		var ans="answer"+x;
		document.getElementById(ans).addEventListener('click',ansclick,false);

	}
	displayques(qno);
}
function ansclick(event)
{
var ansclic=event.target.id;
var ansno=ansclic.charAt(ansclic.length-1);
if(ansno==correct[qno])
{
	correctans();

}else
{
	wrongans();
}
}
function correctans()
{
sound.src="correct.mp3";
sound.play();
score++;
document.getElementById("score").innerHTML="<h4>score:"+score+"</h4>";
if(qno<4)
{
	qno++;
	displayques(qno);

}else
{
	gameover();
}

}
function wrongans()
{
	sound.src="wrong.mp3";
sound.play();
document.getElementById("score").innerHTML="<h4>score:"+score+"</h4>";
if(qno<4)
{
	qno++;
	displayques(qno);
}else
{
	gameover();
}
}
function displayques(qno)
{
	document.getElementById("question").innerHTML="<h4>"+questions[qno]+"</h4>";
	var ansset="";
	switch(qno)
	{
		case 0:
		ansset=quesoneans;
		break;

case 1:
		ansset=questwoans;
		break;	
		case 2:
		ansset=questhreeans;
		break;	
		case 3:
		ansset=quesfourans;
		break;
		case 4:
		ansset=quesfiveans;
		break;
	}
	displayans(ansset);
}
function gameover()
{
document.getElementById("question").innerHTML="<h3>score:"+score+"</h3><h3>Thank you!</h3>";
for(x=0;x<4;x++)
{
	var ansid="answer"+x;
	document.getElementById(ansid).style.display="none";


}
document.getElementById("score").innerHTML="";
}
function displayans(ansset)
{
	for(x=0;x<4;x++)
{
	var ansid="answer"+x;
	document.getElementById(ansid).innerHTML=ansset[x];


}
}





