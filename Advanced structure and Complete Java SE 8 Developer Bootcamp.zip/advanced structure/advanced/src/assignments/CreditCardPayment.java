package assignments;

public class CreditCardPayment {
	public void pay(double amount)
	{
		int service_tax=7;
		float a=(float)amount*service_tax/100;
		System.out.println("Service tax: "+service_tax);
		System.out.println("Credit card amount:"+a);
	}

}
