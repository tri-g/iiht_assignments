package assignments;

public class test14 {
	public static void main(String[] args) {
		Prog14 p=new Prog14();
		System.out.println(p.add(2,2));
		System.out.println(p.add(2,2,5,6,7,8,9));
	}

}
