package assignments;

public class Prog14 {
	 public int add(int ... args){
	        int sum = 0;
	        for(int x: args){
	            sum += x;
	        }
	        return sum;
	    }
}
