package assignments;

public class SavingsAccount extends Account{
	public float interest;
	public SavingsAccount() {
		super();
		this.interest = 5;
	}
	public void display()
	{
		System.out.println("Account number: "+no);
		System.out.println("Name: "+name);
		System.out.println("Saving account interest: "+interest);
	}
	

}
