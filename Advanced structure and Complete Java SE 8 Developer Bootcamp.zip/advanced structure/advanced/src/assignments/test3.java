package assignments;

public class test3 {

	public static void main(String[] args) {
		Mobile m=new Mobile("Android","Samsung","Galaxy J4",20000f);
		m.show();
		Mobile m1=new Mobile("Android","Vivo","S4",50000f);
		m1.show();

	}

}
