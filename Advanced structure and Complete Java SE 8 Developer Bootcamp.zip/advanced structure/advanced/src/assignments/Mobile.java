package assignments;

public class Mobile {
	static int count=1;
	int serial;
	String type;
	String manufacturer;
	String model;
	float price;
	
	public Mobile() {
	}

	public Mobile(String type, String manufacturer, String model, float price) {
		this.type = type;
		this.manufacturer = manufacturer;
		this.model = model;
		this.price = price;
		this.serial=count++;
		
	}
	public void show()
	{
		
		System.out.println("number :"+serial);
		System.out.println("type :"+type);
		System.out.println("manufacturer :"+manufacturer);
		System.out.println("model :"+model);
		System.out.println("price :"+price);
	}

}
