package assignments;
public class test12 {

	public static void main(String[] args) {
		Fruit f=new Fruit("brown",3);
		FruitPredicate p=new FruitPredicate();
		System.out.println("color: "+f.color);
		System.out.println("weight: "+f.weight);
		System.out.println(p.isRed().test(f));

	}

}
