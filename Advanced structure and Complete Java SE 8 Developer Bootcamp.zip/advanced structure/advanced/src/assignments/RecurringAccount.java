package assignments;

public class RecurringAccount extends Account {
	public float interest;

	public RecurringAccount() {
		super();
		this.interest = 8;
	}
	public void display()
	{
		System.out.println("Account number: "+no);
		System.out.println("Name: "+name);
		System.out.println("Recurring account interest: "+interest);
	}
	

}
