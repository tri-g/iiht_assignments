package assignments;

public class test9 {

	public static void main(String[] args) {
		Manager m=new Manager();
		m.display();
		

	}

}
