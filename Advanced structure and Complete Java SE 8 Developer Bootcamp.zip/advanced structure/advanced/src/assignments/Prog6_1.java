package assignments;

public class Prog6_1 {

	public static void main(String[] args) {
int i;
String a="";
for(i=1;i<=100;i++)
{
	if(i%5==0)
	{
		if(i%2==0)
		{
			 a="even";
		}
		else
		{
			 a="odd";
		}
	}
	else
	{
		continue;
	}
	System.out.println(i+" "+a);
}
	}

}
