package assignments;

public class Prog2 {
	{
		System.out.println("welcome to teh doggo world!!");
	}
		String name;
		int age;
		String breed;	
	
	public Prog2(String name,int age,String breed) {
		this.name=name;
		this.age=age;
		this.breed=breed;	
	}
	public void display()
	{
		System.out.println("Name: "+name);
		System.out.println("Age: "+age);
		System.out.println("Breed: "+breed);


	}
}




