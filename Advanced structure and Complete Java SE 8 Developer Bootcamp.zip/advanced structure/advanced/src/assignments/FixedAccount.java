package assignments;

public class FixedAccount extends Account {
	public float interest;

	public FixedAccount() {
		super();
		this.interest = 7;
	}
	public void display()
	{

		System.out.println("Account number: "+no);
		System.out.println("Name: "+name);
		System.out.println("Fixed account interest: "+interest);
	}
	


}
