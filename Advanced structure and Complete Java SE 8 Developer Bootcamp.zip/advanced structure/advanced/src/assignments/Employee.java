package assignments;

public class Employee {
	public String empNumber;
	public String empName;
	public Employee()
	{
		this("109532");
	}
	public Employee(String empNumber)
	{
		this(empNumber,"triveni");
	}
	public Employee(String no,String name)
	{
		this.empNumber=no;
		this.empName=name;
	}
	public void display(String name)
	{
		System.out.println("Name: "+name);
	}
	public void display()
	{
		System.out.println("Name:"+empName);
		System.out.println("ID: "+empNumber);
	}

}
