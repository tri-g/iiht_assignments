package assignments;

public class Manager extends Employee{
	public String has;
	Manager()
	{
		
	}
	public Manager(String id)
	{
		super(id);
	}
	public void display()
	{
		System.out.println("Name:"+empName);
		//System.out.println("ID: "+empNumber);
	}

}
