package assignments;

public class test8 {
	public static void main(String[] args) {
		Prog8 p=new Prog8();
		p.setPastry_type("cupcake");
		p.setFlavour("chocolate");
		p.setQuantity(20);
		System.out.println("Pastry: "+p.getPastry_type());
		System.out.println("Flavour: "+p.getFlavour());
		System.out.println("Quantity: "+p.getQuantity());
		
	}

}
