package assignments;

public class test10 {
	public static void main(String[] args) {
		SavingsAccount s=new SavingsAccount();
		FixedAccount f=new FixedAccount();
		RecurringAccount r=new RecurringAccount();
		s.display();
		System.out.println();
		f.display();
		System.out.println();
		r.display();
	}

}
