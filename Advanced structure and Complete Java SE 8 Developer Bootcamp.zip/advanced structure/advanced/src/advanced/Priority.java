package advanced;
import java.util.*; 
public class Priority { 
	    public static void main(String args[]) 
	    { 
	        PriorityQueue<Integer> queue = new PriorityQueue<Integer>(); 
	        queue.add(10); 
	        queue.add(20); 
	        queue.add(15); 
	        queue.add(2); 
	        queue.add(100); 
	        queue.add(3);
	        queue.add(4); 
	        queue.add(67);

	        
	        PriorityQueue<Integer> queue1 = new PriorityQueue<Integer>(); 
	        while(queue.size()>0) {
	        queue1.add(queue.poll());
	        }

	        System.out.println(queue1);
	    } 
	} 


