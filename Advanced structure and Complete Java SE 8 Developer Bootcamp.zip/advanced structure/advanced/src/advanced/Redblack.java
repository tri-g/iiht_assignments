package advanced;
import java.util.Scanner;



public class Redblack {
	static class Node{
		int key,height;
	     int color;
		Node left;
		Node right;
		Node(int item){
			key=item;
			height=1;
			left=right=null;
			color=1;
		}
		public Node(int theElement, Node lt, Node rt)
	     {
	         left = lt;
	         right = rt;
	         key = theElement;
	         color = 1;
	     } 
	}
	 private Node current;
     private Node parent;
     private Node grand;
     private Node great;
     private Node header;    
     private static Node nullNode;
     static 
     {
         nullNode = new Node(0);
         nullNode.left = nullNode;
         nullNode.right = nullNode;
     }

     static final int BLACK = 1;    
     static final int RED   = 0;

public Redblack(int negInf)
{
    header = new Node(negInf);
    header.left = nullNode;
    header.right = nullNode;
}
public void insert(int item )
{
    current = parent = grand = header;
    nullNode.key = item;
    while (current.key != item)
    {            
        great = grand; 
        grand = parent; 
        parent = current;
        current = item < current.key ? current.left : current.right;
        if (current.left.color == RED && current.right.color == RED)
            handleReorient( item );
    }
    if (current != nullNode)
        return;
    current = new Node(item, nullNode, nullNode);
    if (item < parent.key)
        parent.left = current;
    else
        parent.right = current;        
    handleReorient( item );
}
private void handleReorient(int item)
{
    current.color = RED;
    current.left.color = BLACK;
    current.right.color = BLACK;

    if (parent.color == RED)   
    {
        // Have to rotate
        grand.color = RED;
        if (item < grand.key != item < parent.key)
            parent = rotate( item, grand );  
        current = rotate(item, great );
        current.color = BLACK;
    }
    header.right.color = BLACK; 
} 
private Node rotate(int item, Node parent)
{
    if(item < parent.key)
        return parent.left = item < parent.left.key ? rotateWithLeftChild(parent.left) : rotateWithRightChild(parent.left) ;  
    else
        return parent.right = item < parent.right.key ? rotateWithLeftChild(parent.right) : rotateWithRightChild(parent.right);  
}
private Node rotateWithLeftChild(Node k2)
{
	Node k1 = k2.left;
    k2.left = k1.right;
    k1.right = k2;
    return k1;
}
private Node rotateWithRightChild(Node k1)
{
	Node k2 = k1.right;
    k1.right = k2.left;
    k2.left = k1;
    return k2;
}
private void inorder(Node r)
{
    if (r != nullNode)
    {
        inorder(r.left);
        char c = 'B';
        if (r.color == 0)
            c = 'R';
        System.out.print(r.key +""+c+" ");
        inorder(r.right);
    }
}
public static void main(String[] args) {
	Redblack tree=new Redblack(Integer.MIN_VALUE);
	char ch;
	do {
		Scanner sc=new Scanner(System.in);
		tree.insert(sc.nextInt());
		System.out.println("Do you want to add more elements (Type y or n)");
        ch = sc.next().charAt(0);                        
    } while (ch == 'Y'|| ch == 'y');
	
	tree.inorder(tree.header.right);
}

}