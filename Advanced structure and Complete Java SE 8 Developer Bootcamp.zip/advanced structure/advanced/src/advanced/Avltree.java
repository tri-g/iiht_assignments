package advanced;

import java.util.Scanner;

public class Avltree {
	Node root;
	static class Node{
		int key,height;
		Node left;
		Node right;
		Node(int item){
			key=item;
			height=1;
			left=right=null;
		}
	}
	Avltree()
	{
		root=null;
	}
	public void insert(int data)
    {
        root = insert(data, root);
    }
	private int height(Node node )
    {
        return node == null ? -1 : node.height;
    }
	 private int max(int lhs, int rhs)
     {
         return lhs > rhs ? lhs : rhs;
     }
	 private Node rotateWithLeftChild(Node k2)
     {
		 Node k1 = k2.left;
         k2.left = k1.right;
         k1.right = k2;
         k2.height = max( height( k2.left ), height( k2.right ) ) + 1;
         k1.height = max( height( k1.left ), k2.height ) + 1;
         return k1;
     }
 
     private Node rotateWithRightChild(Node k1)
     {
    	 Node k2 = k1.right;
         k1.right = k2.left;
         k2.left = k1;
         k1.height = max( height( k1.left ), height( k1.right ) ) + 1;
         k2.height = max( height( k2.right ), k1.height ) + 1;
         return k2;
     }
     private Node doubleWithLeftChild(Node k3)
     {
         k3.left = rotateWithRightChild( k3.left );
         return rotateWithLeftChild( k3 );
     }
        
     private Node doubleWithRightChild(Node k1)
     {
         k1.right = rotateWithLeftChild( k1.right );
         return rotateWithRightChild( k1 );
     }    
	 private Node insert(int x, Node node)
     {
         if (node == null)
             node = new Node(x);
         else if (x < node.key)
         {
             node.left = insert( x, node.left );
             if( height( node.left ) - height( node.right ) == 2 )
                 if( x < node.left.key )
                     node = rotateWithLeftChild( node );
                 else
                     node = doubleWithLeftChild( node);
         }
         else if( x > node.key )
         {
             node.right = insert( x, node.right );
             if( height( node.right ) - height( node.left ) == 2 )
                 if( x > node.right.key)
                    node = rotateWithRightChild( node );
                 else
                	 node = doubleWithRightChild( node );
         }
         else
           ;
         node.height = max( height( node.left ), height( node.right ) ) + 1;
         return node;
     }
	 public void inorder(Node node) {
		 if(node==null)
		 {
			 return;
		 }
		 inorder(node.left);
		 System.out.print(node.key+" ");
		 inorder(node.right);
	 }
	 public static void main(String[] args) {
		Avltree tree=new Avltree();
		char ch;
		do {
			Scanner sc=new Scanner(System.in);
			tree.insert(sc.nextInt());
			System.out.println("Do you want to add more elements (Type y or n)");
            ch = sc.next().charAt(0);                        
        } while (ch == 'Y'|| ch == 'y');
		
		tree.inorder(tree.root);
	}

}
