package com.firstspring.hello;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
@RestController
@RequestMapping("/student")
/*@Controller*/
public class App {
 
/*	@RequestMapping("/helloworld")
	public String hello() {
 
		return ("welcome");
	}
}*/
	@RequestMapping(value="/studentJson", method=RequestMethod.GET)
	@ResponseBody
    public Student getStudentJSON()
    {
        Student st = new Student();
        st.setName("Triveni G");
        st.setAge("22");
        
        return st;
    }
}