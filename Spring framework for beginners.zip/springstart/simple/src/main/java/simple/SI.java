package simple;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SI {

	public static void main(String[] args) {
		ApplicationContext application=new ClassPathXmlApplicationContext("Bean.xml");
		SiCalculation calc=(SiCalculation) application.getBean("inte");
		float i=calc.getInterest();
		float t=calc.getTime();
		float p=calc.getPrincipal();
		
		System.out.println("Simple interest: "+(p*t*i)/100);
	}

}
