package project.eg;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class First {
	@RequestMapping("work")
	public String display()
	{
		return "love";
	}

}
