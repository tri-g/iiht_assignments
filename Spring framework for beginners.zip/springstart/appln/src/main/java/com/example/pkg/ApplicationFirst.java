package com.example.pkg;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ApplicationFirst {
	public static void main(String[] args) {
		ApplicationContext application=new ClassPathXmlApplicationContext("Bean.xml");
		/*ApplicationTwo app=(ApplicationTwo)application.getBean("id1");
		 * System.out.println(app.getX()); 
		 * System.out.println(app.getY());
		 */
		
		/*
		 * Animal an=(Animal) application.getBean("bobby");
		 * System.out.println(an.getHeight()); System.out.println(an.getWeight());
		 * System.out.println(an.getName());
		 * System.out.println(an.getColor().getColo());
		 */
		Employee e=(Employee) application.getBean("emp");
		System.out.println(e);
		
		
	}
	
	
	

}
