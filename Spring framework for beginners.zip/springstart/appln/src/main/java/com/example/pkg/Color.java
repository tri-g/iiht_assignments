package com.example.pkg;

public class Color {
	
	private String colo;
	public Color(String color) {
		
		this.colo=color;
	}
	
	

	public String getColo() {
		return colo;
	}

	public void setColo(String colo) {
		this.colo = colo;
	}

	

}
