package com.example.pkg;

public class Animal {
	private double weight;
	private float height;
	private String name;
	private Color color;
	
	public Animal(double weight, float height, String name, Color color) {
		super();
		this.weight = weight;
		this.height = height;
		this.name = name;
		this.color = color;
	}
	public double getWeight() {
		return weight;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}
	public float getHeight() {
		return height;
	}
	public void setHeight(float height) {
		this.height = height;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Color getColor() {
		return color;
	}
	public void setColor(Color color) {
		this.color = color;
	}
	
	
	

}
