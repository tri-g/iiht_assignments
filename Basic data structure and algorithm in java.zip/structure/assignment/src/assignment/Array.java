package assignment;

public class Array {
	public static void print(int a[]) {
		for(int i=0;i<a.length;i++) {
			System.out.print(a[i]+" ");
		}
	}
	public static void insert(int a[],int startindex,int targetindex) {
		int value=a[startindex];
		if(startindex==targetindex)
		{
			return;
		}
		else if(startindex<targetindex)
		{
			for(int i=startindex+1;i<=targetindex;i++) {
				a[i-1]=a[i];
			}
			a[targetindex]=value;
		}
		else {
			for(int i=startindex-1;i>=targetindex;i--) {
				a[i+1]=a[i];
			}
			a[targetindex]=value;
		}
	}
	public static int[] addnewelement(int a[],int value,int index) {
		int new_a[]=new int[a.length+1];
		for(int i=0;i<index;i++)
		{
			new_a[i]=a[i];
		}
		new_a[index]=value;
		for(int i=index+1;i<new_a.length;i++) {
			new_a[i]=a[i-1];
		}
		return new_a;	
	}
	public static void main(String[] args) {
		int a[]= {0,1,2,3,4,5,6,7,34,56,67};
		print(a);
		System.out.println();
		insert(a,9,4);
		print(a);
		System.out.println();
		int ar[]=addnewelement(a,100,9);
		print(ar);
	}

}
