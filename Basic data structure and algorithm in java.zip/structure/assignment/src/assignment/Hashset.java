package assignment;
import java.util.*;  

public class Hashset {

	public static void main(String[] args)  
	{  
	HashSet<String> hs= new HashSet<String>();  
	hs.add("a");  
	hs.add("b");  
	hs.add("c");
	System.out.println("Set is" +hs);      
	Iterator it=hs.iterator();                
	System.out.println("Elements using iterator:");  
	while(it.hasNext())                             
	{  
	String s=(String)it.next();  
	System.out.println(s);  
	}  
	}  
	}  


