package assignment;
import java.util.*;
public class Linked {

	public static void main(String args[]){

	     LinkedList<String> list=new LinkedList<String>();
	     list.add("chandler");
	     list.add("ross");
	     list.add("monica");
	     list.addFirst("joey");
	     list.addFirst("emily");
	     list.addLast("phoebe");
	     list.addLast("gunther");
	     list.add(2, "janice");

	     Iterator<String> iterator=list.iterator();
	     while(iterator.hasNext()){
	       System.out.print(iterator.next()+" ");
	     }
	     System.out.println();
	     list.removeFirst();
	      list.removeLast();
	    System.out.println("LinkedList after deletion of first and last element: " +list);
	      list.add(0, "Joshua");
	      list.remove(2);
	      System.out.println();
	      Iterator<String> iterator1=list.iterator();
		     while(iterator1.hasNext()){
		       System.out.print(iterator1.next()+" ");
		     }
	   } 
	} 
